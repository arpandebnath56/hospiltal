import React, { createContext, useContext, useState, useEffect } from 'react';

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  date: string;
  time: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  reason: string;
  department: string;
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  date: string;
  diagnosis: string;
  treatment: string;
  medications: string[];
  notes: string;
}

export interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  gender: string;
  address: string;
  emergencyContact: string;
  emergencyPhone: string;
  insurance: string;
  registrationDate: string;
}

export interface Bill {
  id: string;
  patientId: string;
  patientName: string;
  amount: number;
  description: string;
  date: string;
  status: 'pending' | 'paid' | 'overdue';
  dueDate: string;
}

interface DataContextType {
  appointments: Appointment[];
  medicalRecords: MedicalRecord[];
  patients: Patient[];
  bills: Bill[];
  addAppointment: (appointment: Omit<Appointment, 'id'>) => void;
  updateAppointment: (id: string, updates: Partial<Appointment>) => void;
  addMedicalRecord: (record: Omit<MedicalRecord, 'id'>) => void;
  addPatient: (patient: Omit<Patient, 'id' | 'registrationDate'>) => void;
  addBill: (bill: Omit<Bill, 'id'>) => void;
  updateBill: (id: string, updates: Partial<Bill>) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);

  useEffect(() => {
    // Load mock data
    const mockAppointments: Appointment[] = [
      {
        id: '1',
        patientId: 'P001',
        patientName: 'Mary Johnson',
        doctorId: '2',
        doctorName: 'Dr. John Smith',
        date: '2024-01-15',
        time: '10:00',
        status: 'scheduled',
        reason: 'Regular checkup',
        department: 'Cardiology',
      },
      {
        id: '2',
        patientId: 'P002',
        patientName: 'Robert Wilson',
        doctorId: '2',
        doctorName: 'Dr. John Smith',
        date: '2024-01-15',
        time: '14:30',
        status: 'completed',
        reason: 'Chest pain consultation',
        department: 'Cardiology',
      },
    ];

    const mockRecords: MedicalRecord[] = [
      {
        id: '1',
        patientId: 'P001',
        patientName: 'Mary Johnson',
        doctorId: '2',
        doctorName: 'Dr. John Smith',
        date: '2024-01-10',
        diagnosis: 'Hypertension',
        treatment: 'Lifestyle changes and medication',
        medications: ['Lisinopril 10mg', 'Amlodipine 5mg'],
        notes: 'Patient responding well to treatment. Follow up in 3 months.',
      },
    ];

    const mockPatients: Patient[] = [
      {
        id: 'P001',
        firstName: 'Mary',
        lastName: 'Johnson',
        email: 'mary.johnson@email.com',
        phone: '+91 98765 43210',
        dateOfBirth: '1985-03-15',
        gender: 'Female',
        address: '123 Main St, Mumbai, Maharashtra 400001',
        emergencyContact: 'John Johnson',
        emergencyPhone: '+91 98765 43211',
        insurance: 'Star Health Insurance',
        registrationDate: '2024-01-01',
      },
      {
        id: 'P002',
        firstName: 'Robert',
        lastName: 'Wilson',
        email: 'robert.wilson@email.com',
        phone: '+91 98765 43212',
        dateOfBirth: '1970-08-22',
        gender: 'Male',
        address: '456 Oak Ave, Delhi, Delhi 110001',
        emergencyContact: 'Sarah Wilson',
        emergencyPhone: '+91 98765 43213',
        insurance: 'HDFC ERGO Health Insurance',
        registrationDate: '2024-01-05',
      },
    ];

    const mockBills: Bill[] = [
      {
        id: '1',
        patientId: 'P001',
        patientName: 'Mary Johnson',
        amount: 2500.00,
        description: 'Cardiology consultation and ECG',
        date: '2024-01-10',
        status: 'paid',
        dueDate: '2024-02-10',
      },
      {
        id: '2',
        patientId: 'P002',
        patientName: 'Robert Wilson',
        amount: 1800.00,
        description: 'Emergency room visit',
        date: '2024-01-12',
        status: 'pending',
        dueDate: '2024-02-12',
      },
    ];

    setAppointments(mockAppointments);
    setMedicalRecords(mockRecords);
    setPatients(mockPatients);
    setBills(mockBills);
  }, []);

  const addAppointment = (appointment: Omit<Appointment, 'id'>) => {
    const newAppointment = { ...appointment, id: Date.now().toString() };
    setAppointments(prev => [...prev, newAppointment]);
  };

  const updateAppointment = (id: string, updates: Partial<Appointment>) => {
    setAppointments(prev => prev.map(apt => apt.id === id ? { ...apt, ...updates } : apt));
  };

  const addMedicalRecord = (record: Omit<MedicalRecord, 'id'>) => {
    const newRecord = { ...record, id: Date.now().toString() };
    setMedicalRecords(prev => [...prev, newRecord]);
  };

  const addPatient = (patient: Omit<Patient, 'id' | 'registrationDate'>) => {
    const newPatient = { 
      ...patient, 
      id: `P${Date.now()}`, 
      registrationDate: new Date().toISOString().split('T')[0] 
    };
    setPatients(prev => [...prev, newPatient]);
  };

  const addBill = (bill: Omit<Bill, 'id'>) => {
    const newBill = { ...bill, id: Date.now().toString() };
    setBills(prev => [...prev, newBill]);
  };

  const updateBill = (id: string, updates: Partial<Bill>) => {
    setBills(prev => prev.map(bill => bill.id === id ? { ...bill, ...updates } : bill));
  };

  return (
    <DataContext.Provider value={{
      appointments,
      medicalRecords,
      patients,
      bills,
      addAppointment,
      updateAppointment,
      addMedicalRecord,
      addPatient,
      addBill,
      updateBill,
    }}>
      {children}
    </DataContext.Provider>
  );
};