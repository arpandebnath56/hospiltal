import React, { createContext, useContext, useState, useEffect } from 'react';

export type UserRole = 'patient' | 'doctor' | 'nurse' | 'admin';

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  avatar?: string;
  specialization?: string;
  department?: string;
  patientId?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: any) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('hospitalUser');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Mock authentication - in production, this would call your API
    const mockUsers: User[] = [
      {
        id: '1',
        email: 'admin@hospital.com',
        firstName: 'Admin',
        lastName: 'User',
        role: 'admin',
      },
      {
        id: '2',
        email: 'doctor@hospital.com',
        firstName: 'Dr. John',
        lastName: 'Smith',
        role: 'doctor',
        specialization: 'Cardiology',
        department: 'Cardiology',
      },
      {
        id: '3',
        email: 'nurse@hospital.com',
        firstName: 'Jane',
        lastName: 'Doe',
        role: 'nurse',
        department: 'Emergency',
      },
      {
        id: '4',
        email: 'patient@hospital.com',
        firstName: 'Mary',
        lastName: 'Johnson',
        role: 'patient',
        patientId: 'P001',
      },
    ];

    const foundUser = mockUsers.find(u => u.email === email);
    if (foundUser && password === 'password123') {
      setUser(foundUser);
      localStorage.setItem('hospitalUser', JSON.stringify(foundUser));
      return true;
    }
    return false;
  };

  const register = async (userData: any): Promise<boolean> => {
    // Mock registration
    const newUser: User = {
      id: Date.now().toString(),
      ...userData,
      role: 'patient',
      patientId: `P${Date.now()}`,
    };
    
    setUser(newUser);
    localStorage.setItem('hospitalUser', JSON.stringify(newUser));
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('hospitalUser');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};