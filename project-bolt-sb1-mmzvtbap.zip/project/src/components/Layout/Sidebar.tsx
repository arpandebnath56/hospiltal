import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Home, 
  Calendar, 
  FileText, 
  CreditCard, 
  Users, 
  Settings,
  Activity,
  Stethoscope,
  AlertTriangle,
  UserPlus,
  BarChart3,
  Search
} from 'lucide-react';

interface NavItem {
  to: string;
  icon: React.ReactNode;
  label: string;
  roles: string[];
}

const navItems: NavItem[] = [
  { to: '/dashboard', icon: <Home className="w-5 h-5" />, label: 'Dashboard', roles: ['admin', 'doctor', 'nurse', 'patient'] },
  { to: '/find-doctor', icon: <Search className="w-5 h-5" />, label: 'Find Doctor', roles: ['patient'] },
  { to: '/appointments', icon: <Calendar className="w-5 h-5" />, label: 'Appointments', roles: ['admin', 'doctor', 'nurse', 'patient'] },
  { to: '/medical-records', icon: <FileText className="w-5 h-5" />, label: 'Medical Records', roles: ['admin', 'doctor', 'nurse', 'patient'] },
  { to: '/patients', icon: <Users className="w-5 h-5" />, label: 'Patients', roles: ['admin', 'doctor', 'nurse'] },
  { to: '/billing', icon: <CreditCard className="w-5 h-5" />, label: 'Billing', roles: ['admin', 'patient'] },
  { to: '/emergency', icon: <AlertTriangle className="w-5 h-5" />, label: 'Emergency', roles: ['admin', 'doctor', 'nurse'] },
  { to: '/register-patient', icon: <UserPlus className="w-5 h-5" />, label: 'Register Patient', roles: ['admin', 'nurse'] },
  { to: '/analytics', icon: <BarChart3 className="w-5 h-5" />, label: 'Analytics', roles: ['admin'] },
  { to: '/settings', icon: <Settings className="w-5 h-5" />, label: 'Settings', roles: ['admin', 'doctor', 'nurse', 'patient'] },
];

export const Sidebar: React.FC = () => {
  const { user } = useAuth();

  const filteredNavItems = navItems.filter(item => 
    user && item.roles.includes(user.role)
  );

  return (
    <aside className="w-64 bg-white shadow-sm border-r border-gray-200 min-h-screen">
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <Stethoscope className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-900">MediCare</h2>
            <p className="text-xs text-gray-600">Hospital Management</p>
          </div>
        </div>
      </div>
      
      <nav className="px-4 pb-4">
        <ul className="space-y-2">
          {filteredNavItems.map((item) => (
            <li key={item.to}>
              <NavLink
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`
                }
              >
                {item.icon}
                <span className="font-medium">{item.label}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};