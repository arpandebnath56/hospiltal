import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useData } from '../../contexts/DataContext';
import { Card, CardHeader, CardContent } from '../../components/UI/Card';
import { Modal } from '../../components/UI/Modal';
import { Calendar, Clock, User, Plus, Edit, CheckCircle, XCircle } from 'lucide-react';

export const Appointments: React.FC = () => {
  const { user } = useAuth();
  const { appointments, addAppointment, updateAppointment } = useData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null);
  const [formData, setFormData] = useState({
    patientName: '',
    doctorName: user?.role === 'doctor' ? `${user.firstName} ${user.lastName}` : '',
    date: '',
    time: '',
    reason: '',
    department: user?.department || '',
  });

  const filteredAppointments = appointments.filter(appointment => {
    if (user?.role === 'patient') {
      return appointment.patientId === user.patientId;
    } else if (user?.role === 'doctor') {
      return appointment.doctorId === user.id;
    }
    return true; // Admin and nurse see all
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAppointment) {
      updateAppointment(selectedAppointment.id, {
        ...formData,
        patientId: selectedAppointment.patientId,
        doctorId: selectedAppointment.doctorId,
      });
    } else {
      addAppointment({
        patientId: user?.role === 'patient' ? user.patientId! : 'P001',
        patientName: formData.patientName,
        doctorId: user?.role === 'doctor' ? user.id : '2',
        doctorName: formData.doctorName,
        date: formData.date,
        time: formData.time,
        status: 'scheduled',
        reason: formData.reason,
        department: formData.department,
      });
    }
    setIsModalOpen(false);
    setSelectedAppointment(null);
    setFormData({
      patientName: '',
      doctorName: user?.role === 'doctor' ? `${user.firstName} ${user.lastName}` : '',
      date: '',
      time: '',
      reason: '',
      department: user?.department || '',
    });
  };

  const handleEdit = (appointment: any) => {
    setSelectedAppointment(appointment);
    setFormData({
      patientName: appointment.patientName,
      doctorName: appointment.doctorName,
      date: appointment.date,
      time: appointment.time,
      reason: appointment.reason,
      department: appointment.department,
    });
    setIsModalOpen(true);
  };

  const handleStatusUpdate = (appointmentId: string, status: 'completed' | 'cancelled') => {
    updateAppointment(appointmentId, { status });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Appointments</h1>
          <p className="text-gray-600">Manage your appointment schedule</p>
        </div>
        
        {(user?.role === 'patient' || user?.role === 'admin') && (
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Book Appointment</span>
          </button>
        )}
      </div>

      <div className="grid gap-6">
        {filteredAppointments.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No appointments found</h3>
              <p className="text-gray-600">
                {user?.role === 'patient' 
                  ? "You don't have any appointments scheduled."
                  : "There are no appointments to display."}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredAppointments.map((appointment) => (
            <Card key={appointment.id}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-4 mb-3">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-5 h-5 text-gray-400" />
                        <span className="font-medium text-gray-900">{appointment.date}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="w-5 h-5 text-gray-400" />
                        <span className="text-gray-600">{appointment.time}</span>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}>
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                      <div>
                        <p className="text-sm text-gray-600">Patient</p>
                        <p className="font-medium text-gray-900">{appointment.patientName}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Doctor</p>
                        <p className="font-medium text-gray-900">{appointment.doctorName}</p>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-sm text-gray-600">Reason</p>
                      <p className="text-gray-900">{appointment.reason}</p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-gray-600">Department</p>
                      <p className="text-gray-900">{appointment.department}</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col space-y-2 ml-6">
                    {(user?.role === 'admin' || user?.role === 'doctor') && appointment.status === 'scheduled' && (
                      <>
                        <button
                          onClick={() => handleStatusUpdate(appointment.id, 'completed')}
                          className="flex items-center space-x-2 px-3 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors"
                        >
                          <CheckCircle className="w-4 h-4" />
                          <span>Complete</span>
                        </button>
                        <button
                          onClick={() => handleStatusUpdate(appointment.id, 'cancelled')}
                          className="flex items-center space-x-2 px-3 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
                        >
                          <XCircle className="w-4 h-4" />
                          <span>Cancel</span>
                        </button>
                      </>
                    )}
                    
                    {(user?.role === 'admin' || (user?.role === 'patient' && appointment.status === 'scheduled')) && (
                      <button
                        onClick={() => handleEdit(appointment)}
                        className="flex items-center space-x-2 px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
                      >
                        <Edit className="w-4 h-4" />
                        <span>Edit</span>
                      </button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedAppointment(null);
          setFormData({
            patientName: '',
            doctorName: user?.role === 'doctor' ? `${user.firstName} ${user.lastName}` : '',
            date: '',
            time: '',
            reason: '',
            department: user?.department || '',
          });
        }}
        title={selectedAppointment ? 'Edit Appointment' : 'Book New Appointment'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          {user?.role !== 'patient' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Patient Name
              </label>
              <input
                type="text"
                required
                value={formData.patientName}
                onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter patient name"
              />
            </div>
          )}

          {user?.role !== 'doctor' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Doctor Name
              </label>
              <input
                type="text"
                required
                value={formData.doctorName}
                onChange={(e) => setFormData({ ...formData, doctorName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter doctor name"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date
              </label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Time
              </label>
              <input
                type="time"
                required
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Department
            </label>
            <select
              required
              value={formData.department}
              onChange={(e) => setFormData({ ...formData, department: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select Department</option>
              <option value="Cardiology">Cardiology</option>
              <option value="Neurology">Neurology</option>
              <option value="Orthopedics">Orthopedics</option>
              <option value="Pediatrics">Pediatrics</option>
              <option value="General Medicine">General Medicine</option>
              <option value="Emergency">Emergency</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Reason for Visit
            </label>
            <textarea
              required
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              placeholder="Describe the reason for this appointment"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              {selectedAppointment ? 'Update Appointment' : 'Book Appointment'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};