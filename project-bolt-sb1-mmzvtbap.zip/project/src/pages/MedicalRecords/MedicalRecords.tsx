import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useData } from '../../contexts/DataContext';
import { Card, CardHeader, CardContent } from '../../components/UI/Card';
import { Modal } from '../../components/UI/Modal';
import { FileText, Plus, Edit, Eye, Calendar, User, Stethoscope, Pill } from 'lucide-react';

export const MedicalRecords: React.FC = () => {
  const { user } = useAuth();
  const { medicalRecords, addMedicalRecord, patients } = useData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<any>(null);
  const [viewMode, setViewMode] = useState<'view' | 'edit' | 'create'>('create');
  const [formData, setFormData] = useState({
    patientName: '',
    patientId: '',
    diagnosis: '',
    treatment: '',
    medications: '',
    notes: '',
    date: new Date().toISOString().split('T')[0],
  });

  const filteredRecords = medicalRecords.filter(record => {
    if (user?.role === 'patient') {
      return record.patientId === user.patientId;
    } else if (user?.role === 'doctor') {
      return record.doctorId === user.id;
    }
    return true; // Admin and nurse see all
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const medicationsArray = formData.medications.split(',').map(med => med.trim()).filter(med => med);
    
    addMedicalRecord({
      patientId: formData.patientId,
      patientName: formData.patientName,
      doctorId: user?.id || '2',
      doctorName: `${user?.firstName} ${user?.lastName}` || 'Dr. John Smith',
      date: formData.date,
      diagnosis: formData.diagnosis,
      treatment: formData.treatment,
      medications: medicationsArray,
      notes: formData.notes,
    });

    setIsModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      patientName: '',
      patientId: '',
      diagnosis: '',
      treatment: '',
      medications: '',
      notes: '',
      date: new Date().toISOString().split('T')[0],
    });
    setSelectedRecord(null);
    setViewMode('create');
  };

  const handleView = (record: any) => {
    setSelectedRecord(record);
    setViewMode('view');
    setIsModalOpen(true);
  };

  const handleEdit = (record: any) => {
    setSelectedRecord(record);
    setFormData({
      patientName: record.patientName,
      patientId: record.patientId,
      diagnosis: record.diagnosis,
      treatment: record.treatment,
      medications: record.medications.join(', '),
      notes: record.notes,
      date: record.date,
    });
    setViewMode('edit');
    setIsModalOpen(true);
  };

  const handleCreate = () => {
    resetForm();
    setViewMode('create');
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Medical Records</h1>
          <p className="text-gray-600">Manage patient medical records and history</p>
        </div>
        
        {(user?.role === 'doctor' || user?.role === 'admin') && (
          <button
            onClick={handleCreate}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Record</span>
          </button>
        )}
      </div>

      <div className="grid gap-6">
        {filteredRecords.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No medical records found</h3>
              <p className="text-gray-600">
                {user?.role === 'patient' 
                  ? "You don't have any medical records yet."
                  : "There are no medical records to display."}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredRecords.map((record) => (
            <Card key={record.id}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{record.diagnosis}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-4 h-4" />
                          <span>{record.date}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <User className="w-4 h-4" />
                          <span>{record.patientName}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Stethoscope className="w-4 h-4" />
                          <span>{record.doctorName}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleView(record)}
                      className="flex items-center space-x-2 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                      <span>View</span>
                    </button>
                    
                    {(user?.role === 'doctor' || user?.role === 'admin') && (
                      <button
                        onClick={() => handleEdit(record)}
                        className="flex items-center space-x-2 px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
                      >
                        <Edit className="w-4 h-4" />
                        <span>Edit</span>
                      </button>
                    )}
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-1">Treatment</p>
                    <p className="text-gray-900">{record.treatment}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-1">Medications</p>
                    <div className="flex flex-wrap gap-1">
                      {record.medications.map((medication: string, index: number) => (
                        <span key={index} className="inline-flex items-center px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                          <Pill className="w-3 h-3 mr-1" />
                          {medication}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                
                {record.notes && (
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-1">Notes</p>
                    <p className="text-gray-900 text-sm">{record.notes}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          resetForm();
        }}
        title={
          viewMode === 'view' ? 'Medical Record Details' :
          viewMode === 'edit' ? 'Edit Medical Record' :
          'Add New Medical Record'
        }
        size="xl"
      >
        {viewMode === 'view' && selectedRecord ? (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Patient</label>
                <p className="text-gray-900">{selectedRecord.patientName}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Doctor</label>
                <p className="text-gray-900">{selectedRecord.doctorName}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <p className="text-gray-900">{selectedRecord.date}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Diagnosis</label>
                <p className="text-gray-900">{selectedRecord.diagnosis}</p>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Treatment</label>
              <p className="text-gray-900">{selectedRecord.treatment}</p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Medications</label>
              <div className="flex flex-wrap gap-2">
                {selectedRecord.medications.map((medication: string, index: number) => (
                  <span key={index} className="inline-flex items-center px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full">
                    <Pill className="w-4 h-4 mr-1" />
                    {medication}
                  </span>
                ))}
              </div>
            </div>
            
            {selectedRecord.notes && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                <p className="text-gray-900">{selectedRecord.notes}</p>
              </div>
            )}
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Patient Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.patientName}
                  onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter patient name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Patient ID
                </label>
                <input
                  type="text"
                  required
                  value={formData.patientId}
                  onChange={(e) => setFormData({ ...formData, patientId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter patient ID"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Date
              </label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Diagnosis
              </label>
              <input
                type="text"
                required
                value={formData.diagnosis}
                onChange={(e) => setFormData({ ...formData, diagnosis: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter diagnosis"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Treatment
              </label>
              <textarea
                required
                value={formData.treatment}
                onChange={(e) => setFormData({ ...formData, treatment: e.target.value })}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                placeholder="Describe the treatment plan"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Medications (comma-separated)
              </label>
              <input
                type="text"
                value={formData.medications}
                onChange={(e) => setFormData({ ...formData, medications: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                placeholder="e.g., Aspirin 100mg, Lisinopril 10mg"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notes
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                placeholder="Additional notes and observations"
              />
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                {viewMode === 'edit' ? 'Update Record' : 'Add Record'}
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};