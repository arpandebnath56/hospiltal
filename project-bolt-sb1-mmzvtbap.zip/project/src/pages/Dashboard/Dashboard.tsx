import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useData } from '../../contexts/DataContext';
import { Card, CardHeader, CardContent } from '../../components/UI/Card';
import { 
  Calendar, 
  Users, 
  FileText, 
  CreditCard, 
  TrendingUp, 
  AlertTriangle,
  Activity,
  Heart
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { appointments, patients, medicalRecords, bills } = useData();

  const getStatsForRole = () => {
    switch (user?.role) {
      case 'admin':
        return [
          { 
            title: 'Total Patients', 
            value: patients.length.toString(), 
            icon: <Users className="w-6 h-6" />,
            color: 'text-blue-600',
            bgColor: 'bg-blue-50'
          },
          { 
            title: 'Today\'s Appointments', 
            value: appointments.filter(apt => apt.date === new Date().toISOString().split('T')[0]).length.toString(), 
            icon: <Calendar className="w-6 h-6" />,
            color: 'text-green-600',
            bgColor: 'bg-green-50'
          },
          { 
            title: 'Pending Bills', 
            value: bills.filter(bill => bill.status === 'pending').length.toString(), 
            icon: <CreditCard className="w-6 h-6" />,
            color: 'text-orange-600',
            bgColor: 'bg-orange-50'
          },
          { 
            title: 'Emergency Cases', 
            value: '3', 
            icon: <AlertTriangle className="w-6 h-6" />,
            color: 'text-red-600',
            bgColor: 'bg-red-50'
          },
        ];
      case 'doctor':
        const doctorAppointments = appointments.filter(apt => apt.doctorId === user.id);
        return [
          { 
            title: 'Today\'s Appointments', 
            value: doctorAppointments.filter(apt => apt.date === new Date().toISOString().split('T')[0]).length.toString(), 
            icon: <Calendar className="w-6 h-6" />,
            color: 'text-blue-600',
            bgColor: 'bg-blue-50'
          },
          { 
            title: 'My Patients', 
            value: doctorAppointments.length.toString(), 
            icon: <Users className="w-6 h-6" />,
            color: 'text-green-600',
            bgColor: 'bg-green-50'
          },
          { 
            title: 'Medical Records', 
            value: medicalRecords.filter(record => record.doctorId === user.id).length.toString(), 
            icon: <FileText className="w-6 h-6" />,
            color: 'text-purple-600',
            bgColor: 'bg-purple-50'
          },
          { 
            title: 'Department', 
            value: user.department || 'General', 
            icon: <Activity className="w-6 h-6" />,
            color: 'text-teal-600',
            bgColor: 'bg-teal-50'
          },
        ];
      case 'nurse':
        return [
          { 
            title: 'Active Patients', 
            value: '15', 
            icon: <Users className="w-6 h-6" />,
            color: 'text-blue-600',
            bgColor: 'bg-blue-50'
          },
          { 
            title: 'Scheduled Tasks', 
            value: '8', 
            icon: <Calendar className="w-6 h-6" />,
            color: 'text-green-600',
            bgColor: 'bg-green-50'
          },
          { 
            title: 'Medications Due', 
            value: '12', 
            icon: <Heart className="w-6 h-6" />,
            color: 'text-red-600',
            bgColor: 'bg-red-50'
          },
          { 
            title: 'Department', 
            value: user.department || 'General', 
            icon: <Activity className="w-6 h-6" />,
            color: 'text-teal-600',
            bgColor: 'bg-teal-50'
          },
        ];
      case 'patient':
        const patientAppointments = appointments.filter(apt => apt.patientId === user.patientId);
        const patientBills = bills.filter(bill => bill.patientId === user.patientId);
        return [
          { 
            title: 'Upcoming Appointments', 
            value: patientAppointments.filter(apt => apt.status === 'scheduled').length.toString(), 
            icon: <Calendar className="w-6 h-6" />,
            color: 'text-blue-600',
            bgColor: 'bg-blue-50'
          },
          { 
            title: 'Medical Records', 
            value: medicalRecords.filter(record => record.patientId === user.patientId).length.toString(), 
            icon: <FileText className="w-6 h-6" />,
            color: 'text-green-600',
            bgColor: 'bg-green-50'
          },
          { 
            title: 'Pending Bills', 
            value: patientBills.filter(bill => bill.status === 'pending').length.toString(), 
            icon: <CreditCard className="w-6 h-6" />,
            color: 'text-orange-600',
            bgColor: 'bg-orange-50'
          },
          { 
            title: 'Health Score', 
            value: '85%', 
            icon: <Heart className="w-6 h-6" />,
            color: 'text-red-600',
            bgColor: 'bg-red-50'
          },
        ];
      default:
        return [];
    }
  };

  const stats = getStatsForRole();

  const getRecentActivity = () => {
    switch (user?.role) {
      case 'admin':
        return [
          { action: 'New patient registered', time: '2 minutes ago', type: 'info' },
          { action: 'Emergency alert resolved', time: '15 minutes ago', type: 'success' },
          { action: 'System backup completed', time: '1 hour ago', type: 'info' },
          { action: 'Staff meeting scheduled', time: '2 hours ago', type: 'info' },
        ];
      case 'doctor':
        return [
          { action: 'Appointment completed with Mary Johnson', time: '30 minutes ago', type: 'success' },
          { action: 'Medical record updated', time: '1 hour ago', type: 'info' },
          { action: 'Prescription sent to pharmacy', time: '2 hours ago', type: 'info' },
          { action: 'Lab results reviewed', time: '3 hours ago', type: 'info' },
        ];
      case 'nurse':
        return [
          { action: 'Medication administered to Room 205', time: '15 minutes ago', type: 'success' },
          { action: 'Vitals recorded for 3 patients', time: '45 minutes ago', type: 'info' },
          { action: 'Emergency response completed', time: '2 hours ago', type: 'success' },
          { action: 'Shift handover completed', time: '4 hours ago', type: 'info' },
        ];
      case 'patient':
        return [
          { action: 'Appointment scheduled with Dr. Smith', time: '1 hour ago', type: 'success' },
          { action: 'Lab results available', time: '2 days ago', type: 'info' },
          { action: 'Prescription refilled', time: '1 week ago', type: 'info' },
          { action: 'Health record updated', time: '2 weeks ago', type: 'info' },
        ];
      default:
        return [];
    }
  };

  const recentActivity = getRecentActivity();

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">
          Welcome back, {user?.firstName}!
        </h1>
        <p className="text-blue-100">
          {user?.role === 'admin' && 'Manage your hospital operations efficiently'}
          {user?.role === 'doctor' && 'Your patients are waiting for your expert care'}
          {user?.role === 'nurse' && 'Ready to provide excellent patient care'}
          {user?.role === 'patient' && 'Manage your health journey with ease'}
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <div className={stat.color}>
                    {stat.icon}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50">
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    activity.type === 'success' ? 'bg-green-400' : 
                    activity.type === 'warning' ? 'bg-orange-400' : 'bg-blue-400'
                  }`}></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">{activity.action}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900">Quick Actions</h3>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {user?.role === 'admin' && (
                <>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors">
                    <Users className="w-6 h-6 text-blue-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Manage Staff</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-green-300 hover:bg-green-50 transition-colors">
                    <TrendingUp className="w-6 h-6 text-green-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">View Reports</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-orange-300 hover:bg-orange-50 transition-colors">
                    <AlertTriangle className="w-6 h-6 text-orange-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Emergency</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-colors">
                    <Calendar className="w-6 h-6 text-purple-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Schedule</div>
                  </button>
                </>
              )}
              
              {user?.role === 'doctor' && (
                <>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors">
                    <Calendar className="w-6 h-6 text-blue-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">View Schedule</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-green-300 hover:bg-green-50 transition-colors">
                    <FileText className="w-6 h-6 text-green-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Medical Records</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-orange-300 hover:bg-orange-50 transition-colors">
                    <Users className="w-6 h-6 text-orange-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Patient List</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-red-300 hover:bg-red-50 transition-colors">
                    <AlertTriangle className="w-6 h-6 text-red-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Emergency</div>
                  </button>
                </>
              )}
              
              {user?.role === 'nurse' && (
                <>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors">
                    <Activity className="w-6 h-6 text-blue-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Patient Care</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-green-300 hover:bg-green-50 transition-colors">
                    <Heart className="w-6 h-6 text-green-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Medications</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-orange-300 hover:bg-orange-50 transition-colors">
                    <Calendar className="w-6 h-6 text-orange-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Schedule</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-red-300 hover:bg-red-50 transition-colors">
                    <AlertTriangle className="w-6 h-6 text-red-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Emergency</div>
                  </button>
                </>
              )}
              
              {user?.role === 'patient' && (
                <>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors">
                    <Calendar className="w-6 h-6 text-blue-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Book Appointment</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-green-300 hover:bg-green-50 transition-colors">
                    <FileText className="w-6 h-6 text-green-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Health Records</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-orange-300 hover:bg-orange-50 transition-colors">
                    <CreditCard className="w-6 h-6 text-orange-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">View Bills</div>
                  </button>
                  <button className="p-4 text-left rounded-lg border border-gray-200 hover:border-red-300 hover:bg-red-50 transition-colors">
                    <AlertTriangle className="w-6 h-6 text-red-600 mb-2" />
                    <div className="text-sm font-medium text-gray-900">Emergency</div>
                  </button>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};