import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { DashboardLayout } from './components/Layout/DashboardLayout';
import { Landing } from './pages/Landing';
import { Login } from './pages/Auth/Login';
import { Register } from './pages/Auth/Register';
import { Dashboard } from './pages/Dashboard/Dashboard';
import { Appointments } from './pages/Appointments/Appointments';
import { MedicalRecords } from './pages/MedicalRecords/MedicalRecords';
import { Billing } from './pages/Billing/Billing';
import { Settings } from './pages/Settings/Settings';
import { DoctorSearch } from './pages/DoctorSearch/DoctorSearch';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  return user ? <>{children}</> : <Navigate to="/login" />;
};

const AppRoutes: React.FC = () => {
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      
      {/* Auth Routes */}
      <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to="/dashboard" /> : <Register />} />
      
      {/* Protected Dashboard Routes */}
      <Route path="/dashboard" element={
        <ProtectedRoute>
          <DashboardLayout>
            <Dashboard />
          </DashboardLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/appointments" element={
        <ProtectedRoute>
          <DashboardLayout>
            <Appointments />
          </DashboardLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/medical-records" element={
        <ProtectedRoute>
          <DashboardLayout>
            <MedicalRecords />
          </DashboardLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/billing" element={
        <ProtectedRoute>
          <DashboardLayout>
            <Billing />
          </DashboardLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/settings" element={
        <ProtectedRoute>
          <DashboardLayout>
            <Settings />
          </DashboardLayout>
        </ProtectedRoute>
      } />

      <Route path="/find-doctor" element={
        <ProtectedRoute>
          <DashboardLayout>
            <DoctorSearch />
          </DashboardLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/patients" element={
        <ProtectedRoute>
          <DashboardLayout>
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Patient Management</h2>
              <p className="text-gray-600">This feature is coming soon...</p>
            </div>
          </DashboardLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/emergency" element={
        <ProtectedRoute>
          <DashboardLayout>
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold text-red-600 mb-4">Emergency Support</h2>
              <p className="text-gray-600 mb-6">For immediate emergency assistance, call:</p>
              <div className="text-4xl font-bold text-red-600">911</div>
            </div>
          </DashboardLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/register-patient" element={
        <ProtectedRoute>
          <DashboardLayout>
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Patient Registration</h2>
              <p className="text-gray-600">This feature is coming soon...</p>
            </div>
          </DashboardLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/analytics" element={
        <ProtectedRoute>
          <DashboardLayout>
            <div className="text-center py-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Analytics & Reports</h2>
              <p className="text-gray-600">This feature is coming soon...</p>
            </div>
          </DashboardLayout>
        </ProtectedRoute>
      } />
      
      {/* Catch all route */}
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <Router>
          <AppRoutes />
        </Router>
      </DataProvider>
    </AuthProvider>
  );
}

export default App;